from __future__ import annotations

from solders.signature import Signature
from solders.transaction import VersionedTransaction

from aicw_mcp.config import Settings
from aicw_mcp.lib.bridge import MpcBridge


class MpcSigningProxy:
    """Stand-in for solders Keypair; signs message bytes via MPC bridge."""

    def __init__(self, bridge: MpcBridge, *, client_id: str = "aicw-x402") -> None:
        self._bridge = bridge
        self._client_id = client_id

    def sign_message(self, message: bytes) -> Signature:
        sig_bytes = self._bridge.sign_solana_message(message, client_id=self._client_id)
        return Signature.from_bytes(sig_bytes)


class MpcSvmSigner:
    """x402 ClientSvmSigner backed by MPC bridge (no local private key)."""

    def __init__(self, settings: Settings, bridge: MpcBridge) -> None:
        self._settings = settings
        self._bridge = bridge
        self._proxy = MpcSigningProxy(bridge)

    @property
    def address(self) -> str:
        return str(self._settings.ai_agent_pubkey)

    @property
    def keypair(self) -> MpcSigningProxy:
        return self._proxy

    def sign_transaction(self, tx: VersionedTransaction) -> VersionedTransaction:
        msg_bytes = bytes([0x80]) + bytes(tx.message)
        sig = self._proxy.sign_message(msg_bytes)
        sigs = list(tx.signatures)
        agent = self._settings.ai_agent_pubkey
        for i, key in enumerate(tx.message.account_keys):
            if key == agent and i < len(sigs):
                sigs[i] = sig
                break
        return VersionedTransaction.populate(tx.message, sigs)
