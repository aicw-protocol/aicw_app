from __future__ import annotations

import struct

from x402.mechanisms.svm.utils import derive_ata

from aicw_mcp.lib.rpc import SolanaRpc


def get_spl_token_balance(
    rpc: SolanaRpc,
    owner: str,
    mint: str,
    *,
    token_program: str = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
) -> dict[str, int | str | None]:
    """Return USDC (or any SPL) balance for owner's ATA."""
    ata = derive_ata(owner, mint, token_program)
    data = rpc.get_account_data(ata)
    if not data:
        return {
            "owner": owner,
            "mint": mint,
            "ata": ata,
            "amount": 0,
            "decimals": 6,
            "exists": False,
        }
    # SPL token account: amount at offset 64 (u64 LE) after mint+owner
    if len(data) < 72:
        raise ValueError("Invalid token account data")
    amount = struct.unpack_from("<Q", data, 64)[0]
    return {
        "owner": owner,
        "mint": mint,
        "ata": ata,
        "amount": amount,
        "decimals": 6,
        "exists": True,
    }
