from __future__ import annotations

import base64
import time
from typing import Any

import requests

from aicw_mcp.config import Settings, mask_wallet_id
from aicw_mcp.lib.errors import is_retryable


class MpcBridge:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.base = settings.mpc_bridge_url

    def health(self) -> dict[str, Any]:
        r = requests.get(f"{self.base}/health", timeout=15)
        r.raise_for_status()
        return r.json()

    def generate_agent_key(self, client_id: str = "aicw-mcp-keygen") -> dict[str, str]:
        body = {"clientId": client_id}
        r = requests.post(
            f"{self.base}/v1/mpc/ai-agent-pubkey",
            json=body,
            timeout=120,
        )
        r.raise_for_status()
        data = r.json()
        return {
            "solanaAddress": data["solanaAddress"],
            "walletId": data["walletId"],
            "walletIdMasked": mask_wallet_id(data["walletId"]),
            "networkCode": data.get("networkCode", self.settings.network_code),
        }

    def sign_solana_message(
        self,
        message_bytes: bytes,
        *,
        client_id: str = "aicw-mcp",
    ) -> bytes:
        body = {
            "clientId": client_id,
            "walletId": self.settings.mpc_wallet_id,
            "messageBytesB64": base64.b64encode(message_bytes).decode("ascii"),
            "networkCode": self.settings.network_code,
            "aiAgentPubkey": str(self.settings.ai_agent_pubkey),
        }
        last: BaseException | None = None
        for attempt in range(4):
            try:
                r = requests.post(
                    f"{self.base}/v1/mpc/sign-solana-message",
                    json=body,
                    timeout=120,
                )
                if r.status_code == 403:
                    raise RuntimeError(f"AICW wallet dead or signing denied: {r.text}")
                r.raise_for_status()
                sig_b64 = r.json()["signatureB64"]
                return base64.b64decode(sig_b64)
            except Exception as e:
                last = e
                if attempt >= 3 or not is_retryable(e):
                    raise
                time.sleep(2.0 * (2**attempt))
        raise last  # type: ignore[misc]
