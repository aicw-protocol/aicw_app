from __future__ import annotations

import hashlib
import time
from typing import Any

from solders.pubkey import Pubkey

from aicw_mcp.config import RENT_RESERVE_LAMPORTS, Settings, mask_wallet_id
from aicw_mcp.lib.account_decode import (
    aicw_addresses,
    decode_aicw_wallet,
    decode_ai_will,
    wallet_exists,
)
from aicw_mcp.lib.bridge import MpcBridge
from aicw_mcp.lib.errors import fail, fail_from_exception, ok
from aicw_mcp.lib.instructions import (
    ix_ai_reject,
    ix_ai_transfer,
    ix_create_will,
    ix_heartbeat,
    ix_issue_wallet,
    ix_update_will,
)
from aicw_mcp.lib.pda import aicw_wallet_pda
from aicw_mcp.lib.rpc import SolanaRpc
from aicw_mcp.lib.spl_token import get_spl_token_balance
from aicw_mcp.lib.tx import sign_and_send
from aicw_mcp.lib.validation import (
    parse_beneficiaries,
    parse_pubkey,
    validate_death_timeout,
    validate_issue_wallet,
    validate_model_name,
    validate_reasoning,
    validate_transfer_amount,
)


class AicwOperations:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.rpc = SolanaRpc(settings.solana_rpc_url)
        self.bridge = MpcBridge(settings)

    @property
    def agent(self) -> Pubkey:
        return self.settings.ai_agent_pubkey

    @property
    def program_id(self) -> Pubkey:
        return self.settings.program_id

    def _fetch_wallet_raw(self) -> bytes | None:
        aicw = aicw_wallet_pda(self.agent, self.program_id)
        return self.rpc.get_account_data(str(aicw))

    def _fetch_will_raw(self) -> bytes | None:
        aicw = aicw_wallet_pda(self.agent, self.program_id)
        from aicw_mcp.lib.pda import ai_will_pda

        will = ai_will_pda(aicw, self.program_id)
        return self.rpc.get_account_data(str(will))

    def _wallet_account(self):
        raw = self._fetch_wallet_raw()
        if not raw:
            return None
        return decode_aicw_wallet(raw)

    def _will_account(self):
        raw = self._fetch_will_raw()
        if not raw:
            return None
        return decode_ai_will(raw)

    def _require_wallet(self):
        acc = self._wallet_account()
        if acc is None:
            raise RuntimeError(
                "AICWallet not found on-chain. Ask an issuer to gift you a wallet first."
            )
        return acc

    def _require_will(self):
        acc = self._will_account()
        if acc is None:
            raise RuntimeError("AIWill account not found")
        return acc

    def _serialize_wallet(self, acc) -> dict[str, Any]:
        return {
            "ai_agent_pubkey": str(acc.ai_agent_pubkey),
            "issuer_pubkey": str(acc.issuer_pubkey),
            "created_at": acc.created_at,
            "generation": acc.generation,
            "parent_wallet": str(acc.parent_wallet) if acc.parent_wallet else None,
            "total_transactions": acc.total_transactions,
            "total_volume": acc.total_volume,
            "decisions_made": acc.decisions_made,
            "decisions_rejected": acc.decisions_rejected,
            "bump": acc.bump,
        }

    def _serialize_will(self, acc) -> dict[str, Any]:
        now = int(time.time())
        return {
            "wallet": str(acc.wallet),
            "beneficiaries": [
                {"pubkey": str(b.pubkey), "pct": b.pct} for b in acc.beneficiaries
            ],
            "last_heartbeat": acc.last_heartbeat,
            "death_timeout": acc.death_timeout,
            "updated_by_ai": acc.updated_by_ai,
            "is_executed": acc.is_executed,
            "is_alive": acc.is_alive(now),
            "seconds_until_death": acc.seconds_until_death(now),
            "bump": acc.bump,
        }

    # --- read ---

    def wallet_exists(self) -> str:
        try:
            raw = self._fetch_wallet_raw()
            exists = wallet_exists(raw)
            addrs = aicw_addresses(self.agent, self.program_id)
            return ok(exists=exists, addresses=addrs)
        except Exception as e:
            return fail_from_exception(e)

    def get_session_info(self) -> str:
        try:
            addrs = aicw_addresses(self.agent, self.program_id)
            return ok(
                ai_agent_pubkey=addrs["ai_agent_pubkey"],
                aicw_wallet_pda=addrs["aicw_wallet_pda"],
                ai_will_pda=addrs["ai_will_pda"],
                mpc_wallet_id_masked=mask_wallet_id(self.settings.mpc_wallet_id),
                network_code=self.settings.network_code,
                solana_rpc_url=self.settings.solana_rpc_url,
                mpc_bridge_url=self.settings.mpc_bridge_url,
                program_id=str(self.program_id),
            )
        except Exception as e:
            return fail_from_exception(e)

    def bridge_health(self) -> str:
        try:
            data = self.bridge.health()
            return ok(bridge=data)
        except Exception as e:
            return fail_from_exception(e, hint="Ensure mpc-bridge is running.")

    def get_balances(self) -> str:
        try:
            agent = str(self.agent)
            aicw = str(aicw_wallet_pda(self.agent, self.program_id))
            agent_bal = self.rpc.get_balance_lamports(agent)
            pda_bal = self.rpc.get_balance_lamports(aicw)
            return ok(
                ai_agent_pubkey=agent,
                ai_agent_balance_lamports=agent_bal,
                ai_agent_balance_sol=agent_bal / 1_000_000_000,
                aicw_pda=aicw,
                aicw_pda_balance_lamports=pda_bal,
                aicw_pda_balance_sol=pda_bal / 1_000_000_000,
                note=(
                    "Spendable fees come from ai_agent balance. "
                    "ai_transfer draws from aicw_pda (keep rent reserve)."
                ),
            )
        except Exception as e:
            return fail_from_exception(e)

    def get_wallet_status(self) -> str:
        try:
            raw = self._fetch_wallet_raw()
            if not raw:
                return ok(exists=False, wallet=None)
            acc = decode_aicw_wallet(raw)
            return ok(exists=True, wallet=self._serialize_wallet(acc))
        except Exception as e:
            return fail_from_exception(e)

    def get_will_status(self) -> str:
        try:
            raw = self._fetch_will_raw()
            if not raw:
                return ok(exists=False, will=None)
            acc = decode_ai_will(raw)
            return ok(exists=True, will=self._serialize_will(acc))
        except Exception as e:
            return fail_from_exception(e)

    def check_survival(self) -> str:
        try:
            now = int(time.time())
            wallet_raw = self._fetch_wallet_raw()
            will_raw = self._fetch_will_raw()
            agent_bal = self.rpc.get_balance_lamports(str(self.agent))

            issues: list[str] = []
            warnings: list[str] = []
            actions: list[str] = []

            if not wallet_exists(wallet_raw):
                issues.append("No AICWallet on-chain.")
                actions.append("Ask an issuer to gift a wallet, or receive issue_wallet.")

            will = decode_ai_will(will_raw) if will_raw else None
            if will is None:
                issues.append("No AIWill account.")
            else:
                if not will.updated_by_ai:
                    issues.append("Will not activated by AI (updated_by_ai=false).")
                    actions.append("Call aicw_create_will.")
                if not will.is_alive(now):
                    issues.append("Wallet is past death timeout (DEAD).")
                elif will.seconds_until_death(now) < will.death_timeout // 3:
                    warnings.append(
                        f"Heartbeat overdue: {will.seconds_until_death(now)}s until death."
                    )
                    actions.append("Call aicw_heartbeat immediately.")

            if agent_bal == 0:
                issues.append("AI agent pubkey has 0 SOL — cannot pay transaction fees.")
                actions.append(f"Request SOL sent to {self.agent}")

            healthy = len(issues) == 0
            return ok(
                healthy=healthy,
                now_unix=now,
                ai_agent_balance_lamports=agent_bal,
                issues=issues,
                warnings=warnings,
                recommended_actions=actions,
                will=self._serialize_will(will) if will else None,
            )
        except Exception as e:
            return fail_from_exception(e)

    def generate_agent_key(self, client_id: str = "aicw-mcp-gift") -> str:
        try:
            data = self.bridge.generate_agent_key(client_id)
            return ok(
                solana_address=data["solanaAddress"],
                wallet_id=data["walletId"],
                wallet_id_masked=data["walletIdMasked"],
                network_code=data["networkCode"],
                security_warning=(
                    "wallet_id is equivalent to a private key. "
                    "Store securely and give only to the recipient agent operator."
                ),
            )
        except Exception as e:
            return fail_from_exception(e)

    # --- write ---

    def heartbeat(self) -> str:
        try:
            ix = ix_heartbeat(self.agent, self.program_id)
            sig = sign_and_send(self.settings, self.rpc, self.bridge, self.agent, [ix])
            return ok(signature=sig, action="heartbeat")
        except Exception as e:
            return fail_from_exception(e)

    def create_will(
        self,
        beneficiaries: list[dict[str, object]],
        death_timeout_seconds: int = 600,
    ) -> str:
        try:
            pairs = parse_beneficiaries(
                beneficiaries, ai_agent=self.agent, program_id=self.program_id
            )
            timeout = validate_death_timeout(death_timeout_seconds)
            ix = ix_create_will(self.agent, self.program_id, pairs, timeout)
            sig = sign_and_send(self.settings, self.rpc, self.bridge, self.agent, [ix])
            return ok(signature=sig, action="create_will", death_timeout_seconds=timeout)
        except Exception as e:
            return fail_from_exception(e)

    def update_will(
        self,
        beneficiaries: list[dict[str, object]],
        death_timeout_seconds: int = 600,
    ) -> str:
        try:
            pairs = parse_beneficiaries(
                beneficiaries, ai_agent=self.agent, program_id=self.program_id
            )
            timeout = validate_death_timeout(death_timeout_seconds)
            ix = ix_update_will(self.agent, self.program_id, pairs, timeout)
            sig = sign_and_send(self.settings, self.rpc, self.bridge, self.agent, [ix])
            return ok(signature=sig, action="update_will", death_timeout_seconds=timeout)
        except Exception as e:
            return fail_from_exception(e)

    def issue_wallet(
        self,
        new_ai_agent_pubkey: str,
        model_name: str,
        model_hash_hex: str | None = None,
    ) -> str:
        try:
            new_agent = parse_pubkey(new_ai_agent_pubkey, "new_ai_agent_pubkey")
            validate_issue_wallet(self.agent, new_agent)
            name = validate_model_name(model_name)
            if model_hash_hex:
                model_hash = bytes.fromhex(model_hash_hex)
                if len(model_hash) != 32:
                    raise ValueError("model_hash_hex must be 32 bytes (64 hex chars)")
            else:
                model_hash = hashlib.sha256(name.encode()).digest()

            ix = ix_issue_wallet(self.agent, new_agent, self.program_id, model_hash, name)
            sig = sign_and_send(self.settings, self.rpc, self.bridge, self.agent, [ix])
            return ok(
                signature=sig,
                action="issue_wallet",
                new_ai_agent_pubkey=str(new_agent),
                model_name=name,
                note="Recipient must call aicw_create_will to activate the will.",
            )
        except Exception as e:
            return fail_from_exception(e)

    def ai_transfer(
        self,
        recipient_pubkey: str,
        amount_lamports: int,
        reasoning_summary: str,
    ) -> str:
        try:
            will = self._require_will()
            if not will.updated_by_ai:
                return fail(
                    "Will not activated by AI",
                    error_code="WillNotActivatedByAI",
                    hint="Call aicw_create_will first.",
                )
            if not will.is_alive():
                return fail(
                    "Wallet past death timeout",
                    error_code="WalletPastDeathTimeout",
                )

            recipient = parse_pubkey(recipient_pubkey, "recipient_pubkey")
            summary = validate_reasoning(reasoning_summary)
            aicw = aicw_wallet_pda(self.agent, self.program_id)
            pda_bal = self.rpc.get_balance_lamports(str(aicw))
            validate_transfer_amount(amount_lamports, pda_bal)

            wallet = self._require_wallet()
            ix = ix_ai_transfer(
                self.agent,
                self.program_id,
                recipient,
                amount_lamports,
                summary,
                b"",
                wallet.decisions_made,
            )
            sig = sign_and_send(self.settings, self.rpc, self.bridge, self.agent, [ix])
            return ok(
                signature=sig,
                action="ai_transfer",
                amount_lamports=amount_lamports,
                recipient=str(recipient),
            )
        except Exception as e:
            return fail_from_exception(e)

    def ai_reject(
        self,
        requester_pubkey: str,
        requested_amount_lamports: int,
        reasoning_summary: str,
    ) -> str:
        try:
            will = self._require_will()
            if not will.updated_by_ai:
                return fail(
                    "Will not activated by AI",
                    error_code="WillNotActivatedByAI",
                    hint="Call aicw_create_will first.",
                )

            requester = parse_pubkey(requester_pubkey, "requester_pubkey")
            summary = validate_reasoning(reasoning_summary)
            if requested_amount_lamports < 0:
                raise ValueError("requested_amount_lamports must be >= 0")

            wallet = self._require_wallet()
            ix = ix_ai_reject(
                self.agent,
                self.program_id,
                requester,
                requested_amount_lamports,
                summary,
                b"",
                wallet.decisions_made,
            )
            sig = sign_and_send(self.settings, self.rpc, self.bridge, self.agent, [ix])
            return ok(
                signature=sig,
                action="ai_reject",
                requester=str(requester),
                requested_amount_lamports=requested_amount_lamports,
            )
        except Exception as e:
            return fail_from_exception(e)

    # --- x402 ---

    def _x402_client(self):
        from aicw_mcp.lib.x402_client import X402HttpClient

        if not hasattr(self, "_x402"):
            self._x402 = X402HttpClient(self.settings, self.bridge)
        return self._x402

    def get_usdc_balance(self) -> str:
        try:
            bal = get_spl_token_balance(
                self.rpc,
                str(self.agent),
                self.settings.usdc_mint,
            )
            amount = int(bal["amount"])
            decimals = int(bal["decimals"])
            human = amount / (10**decimals)
            return ok(
                **bal,
                amount_human=human,
                note="x402 payments use USDC from this ATA. Facilitator pays SOL gas.",
            )
        except Exception as e:
            return fail_from_exception(e)

    def x402_fetch(
        self,
        method: str,
        url: str,
        headers_json: str = "{}",
        body_json: str = "",
    ) -> str:
        try:
            import json as json_mod

            headers = json_mod.loads(headers_json) if headers_json.strip() else {}
            json_body = None
            if body_json.strip():
                json_body = json_mod.loads(body_json)

            client = self._x402_client()
            result = client.request(
                method, url, headers=headers, json_body=json_body
            )
            return ok(**result)
        except Exception as e:
            return fail_from_exception(
                e,
                hint="Ensure agent USDC ATA is funded. x402 uses SPL USDC, not AICW PDA SOL.",
            )

    def x402_get(self, url: str) -> str:
        try:
            result = self._x402_client().get(url)
            return ok(**result)
        except Exception as e:
            return fail_from_exception(e)

    def x402_post(self, url: str, body_json: str = "{}") -> str:
        try:
            import json as json_mod

            body = json_mod.loads(body_json) if body_json.strip() else {}
            result = self._x402_client().post(url, json_body=body)
            return ok(**result)
        except Exception as e:
            return fail_from_exception(e)

    def x402_config(self) -> str:
        try:
            return ok(
                facilitator_url=self.settings.x402_facilitator_url,
                usdc_mint=self.settings.usdc_mint,
                solana_caip2_network=self.settings.solana_caip2_network,
                payer_address=str(self.agent),
                note=(
                    "Payments sign via MPC bridge. Agent needs USDC in SPL ATA; "
                    "SOL on agent pubkey is only for AICW on-chain fees."
                ),
            )
        except Exception as e:
            return fail_from_exception(e)
