# Build aicw_mcp-release.zip for distribution (e.g. aicw_app/public/)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$OutDir = Join-Path $Root "dist"
$ZipName = "aicw_mcp-release.zip"
$ZipPath = Join-Path $OutDir $ZipName

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }

$staging = Join-Path $OutDir "aicw_mcp-staging"
if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
New-Item -ItemType Directory -Force -Path $staging | Out-Null

$include = @(
    "aicw_mcp", "scripts", "install-aicw-mcp.bat",
    "pyproject.toml", "README.md", ".env.example"
)
foreach ($item in $include) {
    $src = Join-Path $Root $item
    if (Test-Path $src) {
        Copy-Item $src -Destination $staging -Recurse -Force
    }
}

Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $ZipPath -Force
Remove-Item $staging -Recurse -Force

Write-Host "Created: $ZipPath"
Write-Host "Copy to aicw_app/public/aicw_mcp-release.zip for GitHub Pages download."
