from __future__ import annotations

import base64
import time

from solders.hash import Hash
from solders.instruction import Instruction
from solders.message import MessageV0, to_bytes_versioned
from solders.pubkey import Pubkey
from solders.signature import Signature
from solders.transaction import VersionedTransaction

from aicw_mcp.config import Settings
from aicw_mcp.lib.bridge import MpcBridge
from aicw_mcp.lib.errors import is_retryable
from aicw_mcp.lib.rpc import SolanaRpc


def sign_and_send(
    settings: Settings,
    rpc: SolanaRpc,
    bridge: MpcBridge,
    ai_agent: Pubkey,
    instructions: list[Instruction],
    *,
    client_id: str = "aicw-mcp",
    max_attempts: int = 4,
) -> str:
    last: BaseException | None = None
    for attempt in range(max_attempts):
        try:
            blockhash = Hash.from_string(rpc.latest_blockhash())
            msg = MessageV0.try_compile(
                payer=ai_agent,
                instructions=instructions,
                address_lookup_table_accounts=[],
                recent_blockhash=blockhash,
            )
            msg_bytes = to_bytes_versioned(msg)
            sig_bytes = bridge.sign_solana_message(msg_bytes, client_id=client_id)
            sig = Signature.from_bytes(sig_bytes)
            vtx = VersionedTransaction.populate(msg, [sig])
            raw = base64.b64encode(bytes(vtx)).decode("ascii")
            return rpc.send_transaction(raw)
        except Exception as e:
            last = e
            if attempt >= max_attempts - 1 or not is_retryable(e):
                raise
            time.sleep(2.0 * (2**attempt))
    raise last  # type: ignore[misc]
