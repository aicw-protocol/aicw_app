from __future__ import annotations

import struct
import time
from dataclasses import dataclass

from solders.pubkey import Pubkey

from aicw_mcp.lib.constants import AICW_WALLET_DISC_LEN, DECISIONS_MADE_OFFSET
from aicw_mcp.lib.pda import ai_will_pda, aicw_wallet_pda


@dataclass
class AICWalletAccount:
    wallet_id: bytes
    ai_agent_pubkey: Pubkey
    issuer_pubkey: Pubkey
    created_at: int
    model_hash: bytes
    generation: int
    parent_wallet: Pubkey | None
    total_transactions: int
    total_volume: int
    decisions_made: int
    decisions_rejected: int
    bump: int


@dataclass
class BeneficiaryShare:
    pubkey: Pubkey
    pct: int


@dataclass
class AIWillAccount:
    wallet: Pubkey
    beneficiaries: list[BeneficiaryShare]
    last_heartbeat: int
    death_timeout: int
    updated_by_ai: bool
    is_executed: bool
    bump: int

    def seconds_until_death(self, now: int | None = None) -> int:
        now = now if now is not None else int(time.time())
        deadline = self.last_heartbeat + self.death_timeout
        return max(0, deadline - now)

    def is_alive(self, now: int | None = None) -> bool:
        now = now if now is not None else int(time.time())
        return now <= self.last_heartbeat + self.death_timeout


def decode_aicw_wallet(data: bytes) -> AICWalletAccount:
    if len(data) < 275:
        raise ValueError("AICWallet account data too short")

    offset = AICW_WALLET_DISC_LEN
    wallet_id = data[offset : offset + 32]
    offset += 32
    ai_agent = Pubkey.from_bytes(data[offset : offset + 32])
    offset += 32
    issuer = Pubkey.from_bytes(data[offset : offset + 32])
    offset += 32
    created_at = struct.unpack_from("<q", data, offset)[0]
    offset += 8
    model_hash = data[offset : offset + 32]
    offset += 32
    generation = data[offset]
    offset += 1

    parent_flag = data[offset]
    offset += 1
    parent_wallet: Pubkey | None = None
    if parent_flag != 0:
        parent_wallet = Pubkey.from_bytes(data[offset : offset + 32])
        offset += 32

    total_tx = struct.unpack_from("<Q", data, offset)[0]
    offset += 8
    total_vol = struct.unpack_from("<Q", data, offset)[0]
    offset += 8
    decisions_made = struct.unpack_from("<Q", data, offset)[0]
    offset += 8
    decisions_rejected = struct.unpack_from("<Q", data, offset)[0]
    offset += 8
    offset += 64  # verifiable_autonomy_proof
    bump = data[offset]

    return AICWalletAccount(
        wallet_id=wallet_id,
        ai_agent_pubkey=ai_agent,
        issuer_pubkey=issuer,
        created_at=created_at,
        model_hash=model_hash,
        generation=generation,
        parent_wallet=parent_wallet,
        total_transactions=total_tx,
        total_volume=total_vol,
        decisions_made=decisions_made,
        decisions_rejected=decisions_rejected,
        bump=bump,
    )


def get_decisions_made_from_raw(data: bytes) -> int:
    return struct.unpack_from("<Q", data, DECISIONS_MADE_OFFSET)[0]


def decode_ai_will(data: bytes) -> AIWillAccount:
    if len(data) < 8 + 32 + 4:
        raise ValueError("AIWill account data too short")

    offset = 8
    wallet = Pubkey.from_bytes(data[offset : offset + 32])
    offset += 32

    beneficiaries_len = struct.unpack_from("<I", data, offset)[0]
    offset += 4
    beneficiaries: list[BeneficiaryShare] = []
    for _ in range(beneficiaries_len):
        pk = Pubkey.from_bytes(data[offset : offset + 32])
        offset += 32
        pct = data[offset]
        offset += 1
        beneficiaries.append(BeneficiaryShare(pubkey=pk, pct=pct))

    last_heartbeat = struct.unpack_from("<q", data, offset)[0]
    offset += 8
    death_timeout = struct.unpack_from("<q", data, offset)[0]
    offset += 8
    updated_by_ai = data[offset] != 0
    offset += 1
    is_executed = data[offset] != 0
    offset += 1
    bump = data[offset]

    return AIWillAccount(
        wallet=wallet,
        beneficiaries=beneficiaries,
        last_heartbeat=last_heartbeat,
        death_timeout=death_timeout,
        updated_by_ai=updated_by_ai,
        is_executed=is_executed,
        bump=bump,
    )


def wallet_exists(account_data: bytes | None) -> bool:
    return account_data is not None and len(account_data) > 0


def aicw_addresses(ai_agent: Pubkey, program_id: Pubkey) -> dict[str, str]:
    aicw = aicw_wallet_pda(ai_agent, program_id)
    will = ai_will_pda(aicw, program_id)
    return {
        "ai_agent_pubkey": str(ai_agent),
        "aicw_wallet_pda": str(aicw),
        "ai_will_pda": str(will),
    }
