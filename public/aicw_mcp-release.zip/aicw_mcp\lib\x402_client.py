from __future__ import annotations

import json
from typing import Any

import requests
from x402 import x402ClientSync
from x402.http.clients.requests import x402_requests
from x402.mechanisms.svm.exact.register import register_exact_svm_client

from aicw_mcp.config import Settings
from aicw_mcp.lib.bridge import MpcBridge
from aicw_mcp.lib.x402_signer import MpcSvmSigner


class X402HttpClient:
    """Paid HTTP client using MPC-backed Solana x402 exact scheme."""

    def __init__(self, settings: Settings, bridge: MpcBridge) -> None:
        self.settings = settings
        self._signer = MpcSvmSigner(settings, bridge)
        self._client = x402ClientSync()
        register_exact_svm_client(
            self._client,
            self._signer,
            rpc_url=settings.solana_rpc_url,
        )
        self._session = x402_requests(self._client)

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        json_body: dict[str, Any] | None = None,
        data: str | None = None,
        timeout: float = 120.0,
    ) -> dict[str, Any]:
        hdrs = dict(headers or {})
        kwargs: dict[str, Any] = {"timeout": timeout, "headers": hdrs}
        if json_body is not None:
            kwargs["json"] = json_body
        if data is not None:
            kwargs["data"] = data

        resp = self._session.request(method.upper(), url, **kwargs)
        payment_response = resp.headers.get("PAYMENT-RESPONSE") or resp.headers.get(
            "X-PAYMENT-RESPONSE"
        )
        settlement: dict[str, Any] | None = None
        if payment_response:
            try:
                import base64

                settlement = json.loads(base64.b64decode(payment_response))
            except Exception:
                settlement = {"raw": payment_response}

        body: Any
        try:
            body = resp.json()
        except Exception:
            body = resp.text

        return {
            "status_code": resp.status_code,
            "ok": resp.ok,
            "headers": dict(resp.headers),
            "body": body,
            "settlement": settlement,
        }

    def get(self, url: str, **kwargs: Any) -> dict[str, Any]:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs: Any) -> dict[str, Any]:
        return self.request("POST", url, **kwargs)
