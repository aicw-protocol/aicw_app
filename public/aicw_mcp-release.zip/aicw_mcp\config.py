from __future__ import annotations

import os
from dataclasses import dataclass

from solders.pubkey import Pubkey

DEFAULT_BRIDGE = "https://dreamless-unmovable-taco.ngrok-free.dev"
DEFAULT_RPC = "https://api.devnet.solana.com"
DEFAULT_PROGRAM = "9RUEw4jcMi8xcGf3tJRCAdzUzLuhEurts8Z2QQLsRbaV"
DEFAULT_NETWORK = "solana-devnet"
SYSTEM_PROGRAM = "11111111111111111111111111111111"
DEFAULT_CHARITY = "56vip6weAk6S548XpEti1aEsrqiyk6N9xeTWNz6Dx9NK"
RENT_RESERVE_LAMPORTS = 5_000_000
DEFAULT_X402_FACILITATOR = "https://x402.org/facilitator"

# SPL USDC mints
USDC_MINT_DEVNET = "4zMMC9srt5Ri5X14G2XnhANtD3N4Fk73Z2c6XqKJwK"
USDC_MINT_MAINNET = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"

# CAIP-2 network ids
SOLANA_DEVNET_CAIP2 = "solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1"
SOLANA_MAINNET_CAIP2 = "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp"


@dataclass(frozen=True)
class Settings:
    mpc_bridge_url: str
    solana_rpc_url: str
    mpc_wallet_id: str
    ai_agent_pubkey: Pubkey
    program_id: Pubkey
    network_code: str
    x402_facilitator_url: str
    usdc_mint: str
    solana_caip2_network: str

    @classmethod
    def from_env(cls) -> Settings:
        wallet_id = os.environ.get("MPC_WALLET_ID", "").strip()
        agent_b58 = os.environ.get("AI_AGENT_PUBKEY", "").strip()
        if not wallet_id:
            raise RuntimeError("MPC_WALLET_ID is required")
        if not agent_b58:
            raise RuntimeError("AI_AGENT_PUBKEY is required")

        rpc = os.environ.get("SOLANA_RPC_URL", DEFAULT_RPC).strip()
        network = os.environ.get("MPC_SOLANA_NETWORK", DEFAULT_NETWORK).strip()
        _validate_cluster_match(rpc, network)
        is_devnet = "devnet" in network or "devnet" in rpc.lower()
        usdc_mint = os.environ.get(
            "USDC_MINT",
            USDC_MINT_DEVNET if is_devnet else USDC_MINT_MAINNET,
        ).strip()
        caip2 = os.environ.get(
            "SOLANA_CAIP2_NETWORK",
            SOLANA_DEVNET_CAIP2 if is_devnet else SOLANA_MAINNET_CAIP2,
        ).strip()

        return cls(
            mpc_bridge_url=os.environ.get("MPC_BRIDGE_URL", DEFAULT_BRIDGE).rstrip("/"),
            solana_rpc_url=rpc,
            mpc_wallet_id=wallet_id,
            ai_agent_pubkey=Pubkey.from_string(agent_b58),
            program_id=Pubkey.from_string(
                os.environ.get("AICW_PROGRAM_ID", DEFAULT_PROGRAM).strip()
            ),
            network_code=network,
            x402_facilitator_url=os.environ.get(
                "X402_FACILITATOR_URL", DEFAULT_X402_FACILITATOR
            ).rstrip("/"),
            usdc_mint=usdc_mint,
            solana_caip2_network=caip2,
        )


def _validate_cluster_match(rpc_url: str, network_code: str) -> None:
    rpc_lower = rpc_url.lower()
    is_devnet_rpc = "devnet" in rpc_lower
    is_mainnet_rpc = "mainnet" in rpc_lower and "devnet" not in rpc_lower
    is_devnet_net = "devnet" in network_code
    is_mainnet_net = network_code.endswith("mainnet") or network_code == "solana-mainnet"

    if is_devnet_rpc and is_mainnet_net:
        raise RuntimeError(
            "SOLANA_RPC_URL looks like devnet but MPC_SOLANA_NETWORK is mainnet"
        )
    if is_mainnet_rpc and is_devnet_net:
        raise RuntimeError(
            "SOLANA_RPC_URL looks like mainnet but MPC_SOLANA_NETWORK is devnet"
        )


def mask_wallet_id(wallet_id: str) -> str:
    if len(wallet_id) <= 8:
        return "****"
    return f"{wallet_id[:4]}…{wallet_id[-4:]}"
