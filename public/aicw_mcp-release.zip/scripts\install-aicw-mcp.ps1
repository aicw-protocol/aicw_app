# AICW MCP — Windows one-click installer (pip + MCP config)
# Run from aicw_mcp repo root via install-aicw-mcp.bat

$ErrorActionPreference = "Stop"

function Write-Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Write-Ok($msg) { Write-Host "OK: $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "WARN: $msg" -ForegroundColor Yellow }

function Resolve-PythonExe {
    foreach ($cmd in @("python", "py")) {
        try {
            $exe = & $cmd -c "import sys; print(sys.executable)" 2>$null
            if (-not $exe) { continue }
            $exe = $exe.Trim()
            if ($exe -match "WindowsApps\\python") { continue }
            $ok = & $exe -c "import sys; print(sys.version_info >= (3, 11))" 2>$null
            if ($ok -eq "True") { return $exe }
        } catch {}
    }
    return $null
}

function Merge-McpJson($path, $serverEntry) {
    $mcp = @{ mcpServers = @{} }
    if (Test-Path $path) {
        try {
            $existing = Get-Content $path -Raw | ConvertFrom-Json
            if ($existing.mcpServers) {
                $existing.mcpServers.PSObject.Properties | ForEach-Object {
                    if ($_.Name -ne "aicw") {
                        $mcp.mcpServers[$_.Name] = $_.Value
                    }
                }
            }
        } catch {
            Write-Warn "Could not parse existing file — backing up"
            Copy-Item $path "$path.bak.$(Get-Date -Format 'yyyyMMddHHmmss')"
        }
    }
    $mcp.mcpServers["aicw"] = $serverEntry
    ($mcp | ConvertTo-Json -Depth 10) | Set-Content -Path $path -Encoding UTF8
}

$RepoRoot = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path (Join-Path $RepoRoot "pyproject.toml"))) {
    Write-Host "ERROR: Run install-aicw-mcp.bat from the aicw_mcp folder." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "  AICW MCP Installer" -ForegroundColor White
Write-Host "  ==================" -ForegroundColor White

# --- Python (absolute path for MCP clients) ---
Write-Step "Checking Python..."
$pythonExe = Resolve-PythonExe
if (-not $pythonExe) {
    Write-Host "ERROR: Python 3.11+ required. Install from https://python.org" -ForegroundColor Red
    exit 1
}
Write-Ok "Python: $pythonExe"

# --- pip install ---
Write-Step "Installing aicw_mcp..."
Push-Location $RepoRoot
& $pythonExe -m pip install -e . -q
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: pip install failed." -ForegroundColor Red
    Pop-Location
    exit 1
}
Pop-Location
Write-Ok "aicw_mcp installed"

# --- credentials ---
Write-Step "Wallet credentials (from aicw_app issuance Copy)"
Write-Host "Paste your Copy block and press Enter twice, OR type each value when prompted."
Write-Host ""

$clip = ""
try { $clip = Get-Clipboard -Raw -ErrorAction SilentlyContinue } catch {}
$parsed = @{}
if ($clip -match "MPC_WALLET_ID=(.+)") { $parsed["MPC_WALLET_ID"] = $Matches[1].Trim() }
if ($clip -match "AI_AGENT_PUBKEY=(.+)") { $parsed["AI_AGENT_PUBKEY"] = $Matches[1].Trim() }
if ($clip -match "MPC_BRIDGE_URL=(.+)") { $parsed["MPC_BRIDGE_URL"] = $Matches[1].Trim() }

function Prompt-OrDefault($label, $default) {
    if ($default) {
        $r = Read-Host "$label [$default]"
        if ([string]::IsNullOrWhiteSpace($r)) { return $default }
        return $r.Trim()
    }
    return (Read-Host $label).Trim()
}

$walletId = Prompt-OrDefault "MPC_WALLET_ID" $parsed["MPC_WALLET_ID"]
$pubkey = Prompt-OrDefault "AI_AGENT_PUBKEY" $parsed["AI_AGENT_PUBKEY"]
$bridge = Prompt-OrDefault "MPC_BRIDGE_URL" $(if ($parsed["MPC_BRIDGE_URL"]) { $parsed["MPC_BRIDGE_URL"] } else { "https://dreamless-unmovable-taco.ngrok-free.dev" })
$network = Prompt-OrDefault "MPC_SOLANA_NETWORK" "solana-devnet"
$rpc = Prompt-OrDefault "SOLANA_RPC_URL" "https://api.devnet.solana.com"

if (-not $walletId -or -not $pubkey -or -not $bridge) {
    Write-Host "ERROR: MPC_WALLET_ID, AI_AGENT_PUBKEY, MPC_BRIDGE_URL are required." -ForegroundColor Red
    exit 1
}

# --- save env file (single source of truth for MCP envFile) ---
$configDir = Join-Path $env:USERPROFILE ".aicw"
New-Item -ItemType Directory -Force -Path $configDir | Out-Null
$envFile = Join-Path $configDir "aicw_mcp.env"
@"
MPC_WALLET_ID=$walletId
AI_AGENT_PUBKEY=$pubkey
MPC_BRIDGE_URL=$bridge
MPC_SOLANA_NETWORK=$network
SOLANA_RPC_URL=$rpc
AICW_PROGRAM_ID=9RUEw4jcMi8xcGf3tJRCAdzUzLuhEurts8Z2QQLsRbaV
"@ | Set-Content -Path $envFile -Encoding UTF8
Write-Ok "Saved $envFile"

# --- MCP config: absolute python + envFile (not bare "python") ---
Write-Step "Writing MCP server config..."
$envFileForJson = ($envFile -replace '\\', '/')
$serverEntry = @{
    command = $pythonExe
    args = @("-m", "aicw_mcp")
    envFile = $envFileForJson
}

$snippetPath = Join-Path $configDir "mcp-aicw-server.json"
($serverEntry | ConvertTo-Json -Depth 10) | Set-Content -Path $snippetPath -Encoding UTF8
Write-Ok "Saved $snippetPath"

$fullMcp = @{ mcpServers = @{ aicw = $serverEntry } }
$fullPath = Join-Path $configDir "mcp-aicw-full.json"
($fullMcp | ConvertTo-Json -Depth 10) | Set-Content -Path $fullPath -Encoding UTF8
Write-Ok "Saved $fullPath"

$defaultMcp = Join-Path $env:USERPROFILE ".cursor\mcp.json"
$mcpPrompt = "Path to MCP client mcp.json (Enter = $defaultMcp)"
$mcpJsonPath = Read-Host $mcpPrompt
if ([string]::IsNullOrWhiteSpace($mcpJsonPath)) {
    $mcpJsonPath = $defaultMcp
} else {
    $mcpJsonPath = $mcpJsonPath.Trim().Trim('"')
}
if ($mcpJsonPath -eq "skip") {
    Write-Host "  Skipped mcp.json merge. Import $fullPath manually." -ForegroundColor Yellow
} else {
    $parent = Split-Path -Parent $mcpJsonPath
    if ($parent -and -not (Test-Path $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    Merge-McpJson $mcpJsonPath $serverEntry
    Write-Ok "Merged aicw into $mcpJsonPath"
}

# --- verify MCP server module wiring ---
Write-Step "Verifying MCP server wiring..."
& $pythonExe -m aicw_mcp.doctor
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: MCP server wiring check failed." -ForegroundColor Red
    exit 1
}

# --- health check ---
Write-Step "Testing mpc-bridge..."
try {
    $health = Invoke-RestMethod -Uri "$bridge/health" -Headers @{"ngrok-skip-browser-warning"="true"} -TimeoutSec 15
    Write-Ok "Bridge: $($health.ok)"
} catch {
    Write-Warn "Bridge health check failed — is mpc-bridge running?"
}

Write-Host ""
Write-Host "  Done! Restart your AI agent MCP (Cursor: toggle aicw off/on), then run aicw_bridge_health." -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to close"
