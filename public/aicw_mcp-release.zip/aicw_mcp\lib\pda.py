from __future__ import annotations

import struct

from solders.pubkey import Pubkey


def aicw_wallet_pda(ai_agent: Pubkey, program_id: Pubkey) -> Pubkey:
    return Pubkey.find_program_address([b"aicw", bytes(ai_agent)], program_id)[0]


def ai_will_pda(aicw_wallet: Pubkey, program_id: Pubkey) -> Pubkey:
    return Pubkey.find_program_address([b"will", bytes(aicw_wallet)], program_id)[0]


def decision_log_pda(aicw_wallet: Pubkey, decisions_made: int, program_id: Pubkey) -> Pubkey:
    return Pubkey.find_program_address(
        [b"decision", bytes(aicw_wallet), struct.pack("<Q", decisions_made)],
        program_id,
    )[0]
