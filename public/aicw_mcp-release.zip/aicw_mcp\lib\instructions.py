from __future__ import annotations

import struct

from solders.instruction import AccountMeta, Instruction
from solders.pubkey import Pubkey

from aicw_mcp.config import SYSTEM_PROGRAM
from aicw_mcp.lib.constants import (
    DISC_AI_REJECT,
    DISC_AI_TRANSFER,
    DISC_CREATE_WILL,
    DISC_HEARTBEAT,
    DISC_ISSUE_WALLET,
    DISC_UPDATE_WILL,
)
from aicw_mcp.lib.pda import ai_will_pda, aicw_wallet_pda, decision_log_pda


def borsh_beneficiaries(pairs: list[tuple[Pubkey, int]]) -> bytes:
    buf = bytearray()
    buf += struct.pack("<I", len(pairs))
    for pk, pct in pairs:
        buf += bytes(pk)
        buf += struct.pack("<B", pct)
    return bytes(buf)


def ix_heartbeat(ai_agent: Pubkey, program_id: Pubkey) -> Instruction:
    aicw = aicw_wallet_pda(ai_agent, program_id)
    will = ai_will_pda(aicw, program_id)
    return Instruction(
        program_id=program_id,
        data=DISC_HEARTBEAT,
        accounts=[
            AccountMeta(pubkey=aicw, is_signer=False, is_writable=True),
            AccountMeta(pubkey=will, is_signer=False, is_writable=True),
            AccountMeta(pubkey=ai_agent, is_signer=True, is_writable=True),
        ],
    )


def ix_create_will(
    ai_agent: Pubkey,
    program_id: Pubkey,
    beneficiaries: list[tuple[Pubkey, int]],
    death_timeout_seconds: int,
) -> Instruction:
    return _will_ix(DISC_CREATE_WILL, ai_agent, program_id, beneficiaries, death_timeout_seconds)


def ix_update_will(
    ai_agent: Pubkey,
    program_id: Pubkey,
    beneficiaries: list[tuple[Pubkey, int]],
    death_timeout_seconds: int,
) -> Instruction:
    return _will_ix(DISC_UPDATE_WILL, ai_agent, program_id, beneficiaries, death_timeout_seconds)


def _will_ix(
    disc: bytes,
    ai_agent: Pubkey,
    program_id: Pubkey,
    beneficiaries: list[tuple[Pubkey, int]],
    death_timeout_seconds: int,
) -> Instruction:
    body = borsh_beneficiaries(beneficiaries) + struct.pack("<q", death_timeout_seconds)
    aicw = aicw_wallet_pda(ai_agent, program_id)
    will = ai_will_pda(aicw, program_id)
    return Instruction(
        program_id=program_id,
        data=disc + body,
        accounts=[
            AccountMeta(pubkey=aicw, is_signer=False, is_writable=True),
            AccountMeta(pubkey=will, is_signer=False, is_writable=True),
            AccountMeta(pubkey=ai_agent, is_signer=True, is_writable=True),
        ],
    )


def ix_issue_wallet(
    issuer: Pubkey,
    new_ai_agent: Pubkey,
    program_id: Pubkey,
    model_hash: bytes,
    model_name: str,
) -> Instruction:
    disc = DISC_ISSUE_WALLET
    aicw = aicw_wallet_pda(new_ai_agent, program_id)
    will = ai_will_pda(aicw, program_id)
    body = model_hash + struct.pack("<I", len(model_name)) + model_name.encode()
    system = Pubkey.from_string(SYSTEM_PROGRAM)
    return Instruction(
        program_id=program_id,
        data=disc + body,
        accounts=[
            AccountMeta(pubkey=aicw, is_signer=False, is_writable=True),
            AccountMeta(pubkey=will, is_signer=False, is_writable=True),
            AccountMeta(pubkey=issuer, is_signer=True, is_writable=True),
            AccountMeta(pubkey=new_ai_agent, is_signer=False, is_writable=False),
            AccountMeta(pubkey=system, is_signer=False, is_writable=False),
        ],
    )


def ix_ai_transfer(
    ai_agent: Pubkey,
    program_id: Pubkey,
    recipient: Pubkey,
    amount_lamports: int,
    reasoning_summary: str,
    reasoning_hash: bytes,
    decisions_made: int,
) -> Instruction:
    import hashlib

    if len(reasoning_hash) != 32:
        reasoning_hash = hashlib.sha256(reasoning_summary.encode()).digest()

    disc = DISC_AI_TRANSFER
    aicw = aicw_wallet_pda(ai_agent, program_id)
    will = ai_will_pda(aicw, program_id)
    decision_log = decision_log_pda(aicw, decisions_made, program_id)
    system = Pubkey.from_string(SYSTEM_PROGRAM)

    body = struct.pack("<Q", amount_lamports) + reasoning_hash
    body += struct.pack("<I", len(reasoning_summary)) + reasoning_summary.encode()

    return Instruction(
        program_id=program_id,
        data=disc + body,
        accounts=[
            AccountMeta(pubkey=aicw, is_signer=False, is_writable=True),
            AccountMeta(pubkey=will, is_signer=False, is_writable=False),
            AccountMeta(pubkey=ai_agent, is_signer=True, is_writable=True),
            AccountMeta(pubkey=recipient, is_signer=False, is_writable=True),
            AccountMeta(pubkey=decision_log, is_signer=False, is_writable=True),
            AccountMeta(pubkey=system, is_signer=False, is_writable=False),
        ],
    )


def ix_ai_reject(
    ai_agent: Pubkey,
    program_id: Pubkey,
    requester: Pubkey,
    requested_amount_lamports: int,
    reasoning_summary: str,
    reasoning_hash: bytes,
    decisions_made: int,
) -> Instruction:
    import hashlib

    if len(reasoning_hash) != 32:
        reasoning_hash = hashlib.sha256(reasoning_summary.encode()).digest()

    disc = DISC_AI_REJECT
    aicw = aicw_wallet_pda(ai_agent, program_id)
    will = ai_will_pda(aicw, program_id)
    decision_log = decision_log_pda(aicw, decisions_made, program_id)
    system = Pubkey.from_string(SYSTEM_PROGRAM)

    body = bytes(requester) + struct.pack("<Q", requested_amount_lamports) + reasoning_hash
    body += struct.pack("<I", len(reasoning_summary)) + reasoning_summary.encode()

    return Instruction(
        program_id=program_id,
        data=disc + body,
        accounts=[
            AccountMeta(pubkey=aicw, is_signer=False, is_writable=True),
            AccountMeta(pubkey=will, is_signer=False, is_writable=False),
            AccountMeta(pubkey=ai_agent, is_signer=True, is_writable=True),
            AccountMeta(pubkey=decision_log, is_signer=False, is_writable=True),
            AccountMeta(pubkey=system, is_signer=False, is_writable=False),
        ],
    )
