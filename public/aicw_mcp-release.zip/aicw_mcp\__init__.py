"""AICW MCP server — on-chain wallet tools for AI agents."""

__version__ = "0.1.0"
