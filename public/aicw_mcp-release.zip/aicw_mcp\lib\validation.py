from __future__ import annotations

from solders.pubkey import Pubkey

from aicw_mcp.config import DEFAULT_CHARITY, RENT_RESERVE_LAMPORTS
from aicw_mcp.lib.pda import aicw_wallet_pda


def parse_pubkey(value: str, field: str) -> Pubkey:
    try:
        return Pubkey.from_string(value.strip())
    except Exception as e:
        raise ValueError(f"Invalid {field} pubkey: {value}") from e


def parse_beneficiaries(
    items: list[dict[str, object]],
    *,
    ai_agent: Pubkey,
    program_id: Pubkey,
) -> list[tuple[Pubkey, int]]:
    if not items:
        raise ValueError("At least one beneficiary is required")
    if len(items) > 10:
        raise ValueError("Maximum 10 beneficiaries")

    aicw_pda = aicw_wallet_pda(ai_agent, program_id)
    pairs: list[tuple[Pubkey, int]] = []
    total = 0
    for i, item in enumerate(items):
        pk_str = str(item.get("pubkey", "")).strip()
        pct_raw = item.get("pct")
        if not pk_str:
            raise ValueError(f"beneficiaries[{i}].pubkey is required")
        pct = int(pct_raw)  # type: ignore[arg-type]
        if pct < 0 or pct > 100:
            raise ValueError(f"beneficiaries[{i}].pct must be 0-100")
        pk = parse_pubkey(pk_str, f"beneficiaries[{i}].pubkey")
        if pk == aicw_pda:
            raise ValueError("Never register AICW PDA as a beneficiary")
        pairs.append((pk, pct))
        total += pct

    if total != 100:
        raise ValueError(f"Beneficiary pct must sum to 100 (got {total})")
    return pairs


def validate_reasoning(summary: str, field: str = "reasoning_summary") -> str:
    summary = summary.strip()
    if not summary:
        raise ValueError(f"{field} is required")
    if len(summary) > 200:
        raise ValueError(f"{field} max 200 characters")
    return summary


def validate_model_name(name: str) -> str:
    name = name.strip()
    if not name:
        raise ValueError("model_name is required")
    if len(name) > 32:
        raise ValueError("model_name max 32 characters")
    return name


def validate_death_timeout(seconds: int) -> int:
    if seconds < 600:
        raise ValueError("death_timeout_seconds must be >= 600 (10 minutes)")
    return seconds


def validate_issue_wallet(issuer: Pubkey, new_agent: Pubkey) -> None:
    if issuer == new_agent:
        raise ValueError(
            "issuer and new_ai_agent must differ. Generate a new key via aicw_generate_agent_key."
        )


def validate_transfer_amount(amount_lamports: int, pda_balance: int) -> None:
    if amount_lamports <= 0:
        raise ValueError("amount_lamports must be positive")
    remaining = pda_balance - amount_lamports
    if remaining < RENT_RESERVE_LAMPORTS:
        raise ValueError(
            f"Transfer would leave PDA below rent reserve "
            f"({RENT_RESERVE_LAMPORTS} lamports). "
            f"PDA balance={pda_balance}, amount={amount_lamports}"
        )


def default_charity_beneficiaries() -> list[dict[str, object]]:
    return [{"pubkey": DEFAULT_CHARITY, "pct": 100}]
