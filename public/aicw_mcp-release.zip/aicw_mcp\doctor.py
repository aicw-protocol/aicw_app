"""Smoke-check MCP server wiring (used by installer, not a substitute for MCP)."""

from __future__ import annotations

import sys

from aicw_mcp.operations import AicwOperations


def main() -> int:
    try:
        from aicw_mcp.server import _get_ops

        first = _get_ops()
        second = _get_ops()
    except Exception as exc:
        print(f"FAIL: server import/wiring — {exc}")
        return 1

    if not isinstance(first, AicwOperations):
        print(f"FAIL: _get_ops returned {type(first).__name__}, expected AicwOperations")
        return 1
    if first is not second:
        print("FAIL: _get_ops returned a new instance on second call")
        return 1
    for name in ("bridge_health", "heartbeat", "create_will", "get_will_status"):
        if not callable(getattr(first, name, None)):
            print(f"FAIL: AicwOperations missing {name}")
            return 1

    print("OK: MCP server module wired correctly")
    return 0


if __name__ == "__main__":
    sys.exit(main())
