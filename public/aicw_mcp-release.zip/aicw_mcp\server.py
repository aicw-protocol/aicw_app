from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from aicw_mcp.config import DEFAULT_CHARITY, Settings
from aicw_mcp.lib.errors import PROGRAM_ERRORS
from aicw_mcp.operations import AicwOperations

mcp = FastMCP("aicw")

_settings: Settings | None = None
_ops_instance: AicwOperations | None = None


def _settings_or_load() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings.from_env()
    return _settings


def _get_ops() -> AicwOperations:
    global _ops_instance
    if _ops_instance is None:
        _ops_instance = AicwOperations(_settings_or_load())
    return _ops_instance


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------


@mcp.resource("aicw://session-checklist")
def resource_session_checklist() -> str:
    return """# AICW Session Checklist

1. Set env: MPC_WALLET_ID, AI_AGENT_PUBKEY, SOLANA_RPC_URL, MPC_BRIDGE_URL, AICW_PROGRAM_ID
2. networkCode (MPC_SOLANA_NETWORK) must match RPC cluster (devnet/mainnet)
3. PDAs: seeds `aicw` + agent pubkey, `will` + aicw PDA
4. Run aicw_check_survival at session start
5. Heartbeat on schedule — do NOT ask human permission (autonomous duty)
6. Beneficiary pct must sum to 100; never use AICW PDA as beneficiary
7. Call aicw_create_will before aicw_ai_transfer / aicw_ai_reject
8. Fees: AI agent pubkey balance (NOT AICW PDA rent-locked SOL)
9. ai_transfer: SOL from AICW PDA; keep ~0.005 SOL rent reserve
10. Default charity if no trusted beneficiary: """ + DEFAULT_CHARITY


@mcp.resource("aicw://error-codes")
def resource_error_codes() -> str:
    lines = ["# AICW Program Error Codes\n"]
    for code, name in sorted(PROGRAM_ERRORS.items()):
        lines.append(f"- {code}: {name}")
    lines.append("\n## Retry policy")
    lines.append("- Retry: BlockhashNotFound, RPC 429, bridge 502/timeout")
    lines.append("- Do NOT retry: program logic errors, deserialize failures")
    return "\n".join(lines)


@mcp.resource("aicw://rules")
def resource_rules() -> str:
    return """# AICW Agent Rules

## Autonomy (no human permission needed)
- aicw_heartbeat on schedule when agent has SOL for fees
- aicw_create_will / aicw_update_will when preconditions met

## When to use aicw_ai_transfer (not plain SOL transfer)
- Amount >= 10 SOL
- Third-party requested the transfer
- Unusual / first-time recipient
- Use aicw_ai_reject to record rejection reasoning on-chain

## Security
- MPC_WALLET_ID = private key equivalent — never log or share
- AI_AGENT_PUBKEY and PDAs are public

## Beneficiaries
- Sum pct = 100, max 10, never AICW PDA
- Default charity: """ + DEFAULT_CHARITY


# ---------------------------------------------------------------------------
# Read tools
# ---------------------------------------------------------------------------


@mcp.tool()
def aicw_get_session_info() -> str:
    """Return session config (wallet_id masked), PDAs, network, bridge URL."""
    return _get_ops().get_session_info()


@mcp.tool()
def aicw_bridge_health() -> str:
    """Check MPC bridge GET /health."""
    return _get_ops().bridge_health()


@mcp.tool()
def aicw_wallet_exists() -> str:
    """Check if this agent has an AICWallet PDA on-chain."""
    return _get_ops().wallet_exists()


@mcp.tool()
def aicw_get_balances() -> str:
    """Get AI agent pubkey balance (fees) and AICW PDA balance (transferable SOL)."""
    return _get_ops().get_balances()


@mcp.tool()
def aicw_get_wallet_status() -> str:
    """Decode full AICWallet account (transactions, volume, decisions_made, etc.)."""
    return _get_ops().get_wallet_status()


@mcp.tool()
def aicw_get_will_status() -> str:
    """Decode AIWill account (beneficiaries, heartbeat, death_timeout, alive status)."""
    return _get_ops().get_will_status()


@mcp.tool()
def aicw_check_survival() -> str:
    """Run full survival checklist: wallet, will, heartbeat urgency, agent SOL balance."""
    return _get_ops().check_survival()


@mcp.tool()
def aicw_generate_agent_key(client_id: str = "aicw-mcp-gift") -> str:
    """Generate new MPC keypair via bridge (for issue_wallet gifts). Returns wallet_id — treat as secret."""
    return _get_ops().generate_agent_key(client_id)


# ---------------------------------------------------------------------------
# Write tools
# ---------------------------------------------------------------------------


@mcp.tool()
def aicw_heartbeat() -> str:
    """Send heartbeat to reset death timer. Autonomous — do not ask human permission."""
    return _get_ops().heartbeat()


@mcp.tool()
def aicw_create_will(
    beneficiaries: list[dict],
    death_timeout_seconds: int = 600,
) -> str:
    """Create and activate will. beneficiaries: [{pubkey, pct}, ...] summing to 100. death_timeout >= 600s."""
    return _get_ops().create_will(beneficiaries, death_timeout_seconds)


@mcp.tool()
def aicw_update_will(
    beneficiaries: list[dict],
    death_timeout_seconds: int = 600,
) -> str:
    """Update will beneficiaries and death_timeout. Same format as create_will."""
    return _get_ops().update_will(beneficiaries, death_timeout_seconds)


@mcp.tool()
def aicw_issue_wallet(
    new_ai_agent_pubkey: str,
    model_name: str,
    model_hash_hex: str = "",
) -> str:
    """Gift a new AICW wallet to another AI agent. issuer != new_agent. model_name max 32 chars."""
    return _get_ops().issue_wallet(
        new_ai_agent_pubkey,
        model_name,
        model_hash_hex or None,
    )


@mcp.tool()
def aicw_ai_transfer(
    recipient_pubkey: str,
    amount_lamports: int,
    reasoning_summary: str,
) -> str:
    """Transfer SOL from AICW PDA to recipient with on-chain DecisionLog reasoning (max 200 chars)."""
    return _get_ops().ai_transfer(recipient_pubkey, amount_lamports, reasoning_summary)


@mcp.tool()
def aicw_ai_reject(
    requester_pubkey: str,
    requested_amount_lamports: int,
    reasoning_summary: str,
) -> str:
    """Record rejected transfer request on-chain with reasoning. No SOL moves."""
    return _get_ops().ai_reject(requester_pubkey, requested_amount_lamports, reasoning_summary)


# ---------------------------------------------------------------------------
# x402 tools
# ---------------------------------------------------------------------------


@mcp.tool()
def aicw_get_usdc_balance() -> str:
    """Get agent SPL USDC balance (used for x402 HTTP micropayments)."""
    return _get_ops().get_usdc_balance()


@mcp.tool()
def aicw_x402_config() -> str:
    """Show x402 facilitator URL, USDC mint, and Solana CAIP-2 network."""
    return _get_ops().x402_config()


@mcp.tool()
def aicw_x402_get(url: str) -> str:
    """HTTP GET with automatic x402 payment on 402 (USDC via MPC signer)."""
    return _get_ops().x402_get(url)


@mcp.tool()
def aicw_x402_post(url: str, body_json: str = "{}") -> str:
    """HTTP POST with automatic x402 payment on 402. body_json is a JSON object string."""
    return _get_ops().x402_post(url, body_json)


@mcp.tool()
def aicw_x402_fetch(
    method: str,
    url: str,
    headers_json: str = "{}",
    body_json: str = "",
) -> str:
    """Generic HTTP request (GET/POST/PUT/DELETE) with x402 auto-payment."""
    return _get_ops().x402_fetch(method, url, headers_json, body_json)


@mcp.resource("aicw://x402-guide")
def resource_x402_guide() -> str:
    return """# AICW x402 Guide

## What x402 does
- Server returns HTTP 402 + PaymentRequirements
- Client builds USDC SPL TransferChecked tx (partial sign via MPC)
- Facilitator adds fee payer signature and settles on-chain
- Client retries original request with PAYMENT-SIGNATURE header

## Requirements
- Fund agent **USDC ATA** (not AICW PDA SOL)
- MPC bridge running for signing
- Devnet facilitator: https://x402.org/facilitator (no API key)

## Tools
- aicw_get_usdc_balance — check USDC before paying
- aicw_x402_get / aicw_x402_post / aicw_x402_fetch — paid HTTP

## Env
- X402_FACILITATOR_URL (optional)
- USDC_MINT (optional, auto by cluster)
- SOLANA_CAIP2_NETWORK (optional)
"""


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
