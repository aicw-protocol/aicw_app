@echo off
title AICW MCP Installer
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-aicw-mcp.ps1"
if errorlevel 1 pause
