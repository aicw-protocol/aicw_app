from __future__ import annotations

import json
import re
from typing import Any

# Anchor AICWError codes (6000 + enum index)
PROGRAM_ERRORS: dict[int, str] = {
    6000: "UnauthorizedSigner",
    6001: "IdentityNotRegistered",
    6002: "InsufficientReputation",
    6003: "ModelNameTooLong",
    6004: "ReasoningSummaryTooLong",
    6005: "InsufficientLamports",
    6006: "BeneficiaryRatioInvalid",
    6007: "HeartbeatStillAlive",
    6008: "WillAlreadyExecuted",
    6009: "WillWalletMismatch",
    6010: "BeneficiaryAccountMismatch",
    6011: "InvalidWillParameters",
    6012: "WillNotActivatedByAI",
    6013: "WalletPastDeathTimeout",
    6014: "ArithmeticOverflow",
}

RETRYABLE_PATTERNS = (
    "blockhashnotfound",
    "block height exceeded",
    "429",
    "too many requests",
    "502",
    "503",
    "504",
    "timeout",
    "timed out",
    "connection",
    "temporarily unavailable",
)

NON_RETRYABLE_PATTERNS = (
    "instructiondidnotdeserialize",
    "sanitize accounts",
    "simulation failed",
    "custom program error",
    "insufficient funds",
    "unauthorized",
    "willnotactivated",
    "walletpastdeathtimeout",
    "beneficiary",
)


def is_retryable(exc: BaseException) -> bool:
    msg = str(exc).lower()
    for pat in NON_RETRYABLE_PATTERNS:
        if pat in msg:
            return False
    for pat in RETRYABLE_PATTERNS:
        if pat in msg:
            return True
    return False


def parse_program_error(message: str) -> str | None:
    lower = message.lower()
    m = re.search(r"custom program error: 0x([0-9a-f]+)", lower)
    if m:
        code = int(m.group(1), 16)
        return PROGRAM_ERRORS.get(code, f"ProgramError_{code}")
    m = re.search(r"error code: (\d+)", lower)
    if m:
        code = int(m.group(1))
        return PROGRAM_ERRORS.get(code, f"ProgramError_{code}")
    for code, name in PROGRAM_ERRORS.items():
        if name.lower() in lower:
            return name
    return None


def ok(**payload: Any) -> str:
    return json.dumps({"ok": True, **payload}, ensure_ascii=False)


def fail(
    message: str,
    *,
    error_code: str = "Error",
    retryable: bool = False,
    hint: str | None = None,
    **extra: Any,
) -> str:
    body: dict[str, Any] = {
        "ok": False,
        "error_code": error_code,
        "retryable": retryable,
        "message": message,
    }
    if hint:
        body["hint"] = hint
    body.update(extra)
    return json.dumps(body, ensure_ascii=False)


def fail_from_exception(exc: BaseException, *, hint: str | None = None) -> str:
    msg = str(exc)
    prog = parse_program_error(msg)
    if prog:
        hints = {
            "WillNotActivatedByAI": "Call aicw_create_will first.",
            "WalletPastDeathTimeout": "Wallet is dead. Call aicw_heartbeat if still within window.",
            "InsufficientLamports": "Deposit SOL to AICW PDA; keep ~0.005 SOL rent reserve.",
            "BeneficiaryRatioInvalid": "Beneficiary pct values must sum to 100.",
        }
        return fail(
            msg,
            error_code=prog,
            retryable=False,
            hint=hint or hints.get(prog),
        )
    retryable = is_retryable(exc)
    return fail(msg, error_code=type(exc).__name__, retryable=retryable, hint=hint)
