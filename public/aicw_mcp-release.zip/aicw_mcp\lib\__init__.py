"""Solana / MPC helpers for AICW MCP tools."""
