from __future__ import annotations

import base64
import time
from typing import Any

import requests

from aicw_mcp.lib.errors import is_retryable


class SolanaRpc:
    def __init__(self, rpc_url: str, timeout: float = 60.0) -> None:
        self.rpc_url = rpc_url
        self.timeout = timeout

    def call(self, method: str, params: list[Any]) -> Any:
        r = requests.post(
            self.rpc_url,
            json={"jsonrpc": "2.0", "id": 1, "method": method, "params": params},
            timeout=self.timeout,
        )
        r.raise_for_status()
        body = r.json()
        if "error" in body:
            err = body["error"]
            code = err.get("code", "")
            msg = err.get("message", str(err))
            raise RuntimeError(f"RPC {method} failed ({code}): {msg}")
        return body["result"]

    def call_with_retry(
        self,
        method: str,
        params: list[Any],
        *,
        max_attempts: int = 4,
        base_delay: float = 2.0,
    ) -> Any:
        last: BaseException | None = None
        for attempt in range(max_attempts):
            try:
                return self.call(method, params)
            except Exception as e:
                last = e
                if attempt >= max_attempts - 1 or not is_retryable(e):
                    raise
                time.sleep(base_delay * (2**attempt))
        raise last  # type: ignore[misc]

    def get_balance_lamports(self, pubkey: str) -> int:
        out = self.call_with_retry("getBalance", [pubkey, {"commitment": "confirmed"}])
        if isinstance(out, dict) and "value" in out:
            return int(out["value"])
        return int(out)

    def latest_blockhash(self) -> str:
        return self.call_with_retry(
            "getLatestBlockhash", [{"commitment": "confirmed"}]
        )["value"]["blockhash"]

    def get_account_data(self, pubkey: str) -> bytes | None:
        resp = self.call_with_retry(
            "getAccountInfo",
            [pubkey, {"encoding": "base64", "commitment": "confirmed"}],
        )
        if not resp or not resp.get("value"):
            return None
        return base64.b64decode(resp["value"]["data"][0])

    def send_transaction(self, raw_b64: str) -> str:
        return self.call_with_retry(
            "sendTransaction",
            [
                raw_b64,
                {
                    "encoding": "base64",
                    "skipPreflight": False,
                    "preflightCommitment": "confirmed",
                },
            ],
        )
